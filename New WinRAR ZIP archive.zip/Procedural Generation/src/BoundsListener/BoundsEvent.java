package BoundsListener;

import java.awt.AWTEvent;

public class BoundsEvent extends AWTEvent
{
    public static final int BOUND_FIRST = AWTEvent.RESERVED_ID_MAX +1;
    public static final int BOUND_UP = BOUND_FIRST + 1;
    public static final int BOUND_DOWN = BOUND_FIRST + 2;
    public static final int BOUND_LEFT = BOUND_FIRST + 3;
    public static final int BOUND_RIGHT = BOUND_FIRST + 4;
    
    public BoundsEvent(Object source, int id) 
    {
        super(source, id);
    }
    
}
