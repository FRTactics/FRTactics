package BoundsListener;

import java.awt.AWTEventMulticaster;
import java.util.EventListener;

public class BoundsEventMulticaster extends AWTEventMulticaster implements BoundsListener
{
    protected BoundsEventMulticaster(EventListener a, EventListener b)
    {
        super(a,b);
    }
    
    public static BoundsListener add(BoundsListener a, BoundsListener b)
    {
        return (BoundsListener) addInternal(a,b);
    }
    
    public static BoundsListener remove(BoundsListener a, BoundsListener b)
    {
        return (BoundsListener) removeInternal(a,b);
    }
    
    //Overriding method from AWTEventMulticaster
    protected static EventListener addInternal(EventListener a, EventListener b)
    {
        if(a == null)
            return b;
        if(b == null)
            return a;
        return new BoundsEventMulticaster(a,b);
    }
    
    @Override
    protected EventListener remove(EventListener oldl) 
    {
        if (oldl == a) 
            return b;
        if (oldl == b) 
            return a;
        EventListener a2 = removeInternal(a, oldl);
        EventListener b2 = removeInternal(b, oldl);
        if (a2 == a && b2 == b) 
            return this;
        return addInternal(a2, b2);
    }
    @Override
    public void scrollLeft(BoundsEvent event) 
    {
        if(a != null)
            ((BoundsListener)a).scrollLeft(event);
        if(b != null)
            ((BoundsListener)a).scrollLeft(event);
    }

    @Override
    public void scrollRight(BoundsEvent event) 
    {
        if(a != null)
            ((BoundsListener)a).scrollRight(event);
        if(b != null)
            ((BoundsListener)a).scrollRight(event);
    }

    @Override
    public void scrollUp(BoundsEvent event) 
    {
        if(a != null)
            ((BoundsListener)a).scrollUp(event);
        if(b != null)
            ((BoundsListener)a).scrollUp(event);
    }

    @Override
    public void scrollDown(BoundsEvent event) 
    {
        if(a != null)
            ((BoundsListener)a).scrollUp(event);
        if(b != null)
            ((BoundsListener)a).scrollUp(event);
    }
    
}
