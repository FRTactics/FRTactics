/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BoundsListener;

import java.util.EventListener;

public interface BoundsListener extends EventListener
{
    public void scrollLeft(BoundsEvent event);
    public void scrollRight(BoundsEvent event);
    public void scrollUp(BoundsEvent event);
    public void scrollDown(BoundsEvent event);
}
