package BoundsListener;


import java.awt.AWTEvent;
import javax.swing.JViewport;


public class ViewPort extends JViewport 
{
    transient BoundsListener boundsListener;
    
    @Override
    protected void processEvent(AWTEvent event)
    {
        super.processEvent(event);
        if(event instanceof BoundsEvent)
        {
            processBoundsEvent((BoundsEvent) event);
        }
    }

    public synchronized void addBoundsListener(BoundsListener l)
    {
         boundsListener = BoundsEventMulticaster.add(boundsListener, l);
    }
    
    public synchronized void removeBoundsListener(BoundsListener l)
    {
        boundsListener = BoundsEventMulticaster.remove(boundsListener, l);
    }
    
    private void processBoundsEvent(BoundsEvent event) 
    {
        BoundsListener listener = boundsListener;
        
        switch(event.getID())
        {
            case BoundsEvent.BOUND_DOWN:
                listener.scrollDown(event);
                break;
            case BoundsEvent.BOUND_UP:
                listener.scrollUp(event);
                break;
            case BoundsEvent.BOUND_LEFT:
                listener.scrollLeft(event);
                break;
            case BoundsEvent.BOUND_RIGHT:
                listener.scrollRight(event);
                break;
        }
    }
}
