package Model.ClassSystem;

public abstract class DefaultClass {

    //This is the default class in which all class are built from
    
   public void calcStrength(){
       
   }
   
   
   public double calcChanceToDodge(){
             
       return 0;  
   } 
   
   public double calcDamageReduction(double incoming){
            
       return 0;  
   }
   
   public double calcMovement(){
             
       return 0;    
   }
   
   public double calcSpellDamage(){
       
       return 0;
           
   }
     
   public double calcRangedDamage(){
       
       return 0;      
   }
   
   public void calcHealth(){
       
       
   }
   
   public double calcMeleeDamage(){
       
       return 0;
       
   }
   
   public double calcRangeRange(){
       
       return 0;
       
   }
   
   public double calcMeleeRange(){
       
       return 0;
       
   }
   

}