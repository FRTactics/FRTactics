package Exception;

public class InstanceNotCreatedException extends Exception
{
    public InstanceNotCreatedException(String message)
    {
        super(message);
    }
}
